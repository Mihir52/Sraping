# import hashlib
# from string import hexdigits
# from tkinter.constants import RAISED
#
# from encodings.utf_7 import encode
# import pymysql
# from pymongo import MongoClient
# from pymysql.constants.FIELD_TYPE import TIMESTAMP
# from pywinauto.mouse import scroll
# from selenium import webdriver
# from selenium.webdriver.common.by import By
# from selenium.webdriver.chrome.service import Service
# from twisted.conch.insults.window import cursor
# from twisted.names.client import query
# from webdriver_manager.chrome import ChromeDriverManager
# from webdriver_manager.microsoft import EdgeChromiumDriverManager
# import datetime
# import time
# import os
#
# def generate_hashid(url):
#     return hashlib.md5(url.encode()).hexdigits()
#
# def database_creation():
#     try:
#         db = pymysql.connect(host="localhost", user='root', password="xbyte")
#         cursor = db.cursor()
#
#         cursor.execute(f"CREATE DATABASE IF NOT EXISTS zomato_4000010_250313_125102__thursday")
#         db.commit()
#         print("db created")
#     except Exception as e:
#         print("database_creation****", e)
#
#     try:
#         db = pymysql.connect(host="localhost", user="root", password="xbyte", database="zomato_4000010_250313_125102__thursday")
#         cursor = db.cursor()
#
#         cursor.execute("""
#             CREATE TABLE IF NOT EXISTS Zip_code_pdp_4000010(
#                 ID INT NOT NULL AUTO_INCREMENT,
#                 hash_id TEXT UNIQUE,
#                 Product_url TEXT,
#                 Restaurant_name TEXT,
#                 Ratings TEXT,
#                 Open_timing TEXT,
#                 Phone_no TEXT,
#                 Img_url TEXT,
#                 Address TEXT,
#                 Restaurant_Desc TEXT,
#                 Status VARCHAR(50) DEFAULT "Pending",
#                 PRIMARY KEY (ID)
#             )
#         """)
#
#         db.commit()
#         print("table created")
#     except Exception as e:
#         print("Table creation****", e)
#
#     return db, cursor
#
# def fetch_urls():
#     conn, cursor = database_creation()
#     try:
#         query = "SELECT Product_url FROM zip_pl_code_4000010"
#         cursor.execute(query)
#         urls = cursor.fetchall()
#         # urls = [url[0] for url in urls]
#         # print(urls)
#         return urls
#
#     except Exception as e:
#         print("Error fetching product URLs:", e)
#
#     finally:
#         cursor.close()
#         conn.close()
#
# def scrape_data(url):
#     driver = webdriver.Edge()
#     driver.maximize_window()
#     try:
#         driver.get(url)
#         time.sleep(5)
#
#         try:
#             html_content = driver.page_source
#             directory = "C:\\Users\\mihir.parate\\Desktop\\Weekly_Test\\Zomato_zipcodes\\4000010_pdp_html_pages"
#             os.makedirs(directory,exist_ok=True)
#             file_name = directory + "\\" + f"{generate_hashid(url)}.html"
#             # file_name = directory + "\\" + f"{hashlib.sha256(url.encode()).hexdigest()}.html"
#             with open(file_name,'w',encoding="utf-8") as f:
#                 f.write(html_content)
#             print(f"saved html : {file_name}")
#         except Exception as e:
#             print(f"***Html file error : {e}")
#
#         try:
#             # //h4[@class="sc-kKBQAD glfHFU"]
#             # name_ele = driver.find_elements(By.XPATH,'//h4[@class="sc-kKBQAD glfHFU"]/text()')
#             # name = name_ele.text.strip()
#             name = driver.find_elements(By.XPATH,'//h1[@class="sc-7kepeu-0 sc-iSDuPN fwzNdh"]')
#             restaurant_name = [n.text for n in name]
#         except Exception as e:
#             print(f"***name error : {e}")
#
#         try:
#             Rating = driver.find_elements(By.XPATH,'//div[@class="sc-hfsWMF cOzgMB"]')
#             Rating_text = [r.text for r in Rating]
#         except Exception as e:
#             print(f'***Rating error : {e}')
#
#         try:
#             open_timing = driver.find_elements(By.XPATH,'//span[@class="sc-kasBVs dfwCXs"]')
#             timing_text = [t.text for t in open_timing]
#         except Exception as e:
#             print(f"***Open timing error : {e}")
#
#         try:
#             phone_number = driver.find_elements(By.XPATH,'//a[@class="sc-bFADNz leEVAg"]')
#             phone_text = [p.text for p in phone_number]
#             # for p in price:
#             #     price = p.text
#         except Exception as e:
#             print(f"***Phone number error : {e}")
#
#         try:
#             img_url = driver.find_elements(By.XPATH,'//div[@class="sc-iipuKH dNVxsS"]/div/img//div[@class="sc-iipuKH dNVxsS"]/div/img')
#             for i in img_url:
#                 i.get_attribute('src')
#                 img_url = i
#                 print(img_url)
#
#         except Exception as e:
#             print(f"***Img_url error : {e}")
#
#         try:
#             address = driver.find_elements(By.XPATH,'//div[@class="sc-clNaTc ckqoPM"]')
#             address_text = [a.text for a in address]
#         except Exception as e:
#             print(f"***adress error : {e}")
#
#         try:
#             description = driver.find_elements(By.XPATH,'//div[@class="sc-ZUflv bAkeQY"]//div/a')
#             description_text = [d.text for d in description]
#             # description = description_ele.text.strip()
#             # for d in description:
#             #     description = d.text
#         except Exception as e:
#             print(f"***Description error : {e}")
#
#         print(f"Url  : {url}")
#         print(f"Name : {restaurant_name}")
#         print(f"Timing : {timing_text}")
#         print(f"Phone no : {phone_text}")
#         print(f"img_url : {img_url}")
#         print(f"Address : {address_text}")
#         print(f"description : {description_text}")
#
#         store_data = ([{"Url":url,"Name": restaurant_name,"Timing" : timing_text,"Phone no" :phone_text,"Img_url" : img_url,"Address" : address_text,"Description" : description_text}])
#
#     except Exception as e:
#         print(f"Scrape data error {url} : {e}")
#
#     finally:
#         driver.quit()
#
# urls_to_scrape= fetch_urls()
# if urls_to_scrape:
#     for url in urls_to_scrape:
#         scrape_data(url)
# else:
#     print("Not found urls")
#
#
#
#
#
#
#
#
#
#

import hashlib
import os
import time
import pymysql
import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.by import By

def generate_hashid(url):
    return hashlib.md5(url.encode()).hexdigest()

def database_creation():
    try:
        db = pymysql.connect(host="localhost", user='root', password="xbyte")
        cursor = db.cursor()
        cursor.execute("CREATE DATABASE IF NOT EXISTS zomato_4000010_250313_125102__thursday")
        db.commit()
        print("Database created")
    except Exception as e:
        print("Database creation error:", e)

    try:
        db = pymysql.connect(host="localhost", user="root", password="xbyte", database="zomato_4000010_250313_125102__thursday")
        cursor = db.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS zip_code_pdp_4000010 (
                ID INT NOT NULL AUTO_INCREMENT,
                hash_id TEXT,
                Product_url TEXT,
                Restaurant_name TEXT,
                Ratings TEXT,
                Open_timing TEXT,
                Phone_no TEXT,
                Img_url TEXT,
                Address TEXT,
                Restaurant_Desc TEXT,
                Status VARCHAR(50) DEFAULT "Pending",
                PRIMARY KEY (ID)
            )
        """)
        db.commit()
        print("Table created")
    except Exception as e:
        print("Table creation error:", e)
    return db, cursor

def fetch_urls():
    conn, cursor = database_creation()
    try:
        cursor.execute("SELECT Product_url FROM zip_pl_code_4000010")
        urls = cursor.fetchall()
        return [url[0] for url in urls]
    except Exception as e:
        print("Error fetching URLs:", e)
    finally:
        cursor.close()
        conn.close()

def insert_data(db, cursor, url, names, ratings, timings, phones, img_urls, addresses, descriptions):
    try:
        hash_id = generate_hashid(url)
        cursor.execute("""
            INSERT INTO zip_code_pdp_4000010 (hash_id, Product_url, Restaurant_name, Ratings, Open_timing, Phone_no, Img_url, Address, Restaurant_Desc, Status)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, 'Done')
        """, (hash_id, url, ", ".join(names), ", ".join(ratings), ", ".join(timings), ", ".join(phones), ", ".join(img_urls), ", ".join(addresses), ", ".join(descriptions)))
        db.commit()
        print("Data inserted successfully")
    except Exception as e:
        print("Insertion error:", e)

def scroll_and_collect_images(driver):
    last_height = driver.execute_script("return document.body.scrollHeight")

    while True:
        # Scroll down
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(2)  # Wait for new images to load

        new_height = driver.execute_script("return document.body.scrollHeight")
        if new_height == last_height:
            break  # Stop if no more scrolling
        last_height = new_height

    # Collect all images
    img_urls = [elem.get_attribute('src') for elem in driver.find_elements(By.TAG_NAME, 'img') if elem.get_attribute('src')]
    return img_urls

def scrape_data(url):
    driver = webdriver.Edge()
    driver.maximize_window()
    try:
        driver.get(url)
        time.sleep(5)

        hash_id = generate_hashid(url)
        directory = "./Zomato_PDP_HTML"
        os.makedirs(directory, exist_ok=True)
        file_name = os.path.join(directory, f"{hash_id}.html")
        with open(file_name, 'w', encoding="utf-8") as f:
            f.write(driver.page_source)
        print(f"Saved HTML: {file_name}")

        names = [elem.text for elem in driver.find_elements(By.XPATH, '//h1[@class="sc-7kepeu-0 sc-iSDuPN fwzNdh"]')]
        # for ele in driver.find_elements(By.XPATH,'//h1[@class="sc-7kepeu-0 sc-iSDuPN fwzNdh"]'):
        #     names = ele.text
        #     print(names)
        ratings_raw = [elem.get_attribute('title') for elem in driver.find_elements(By.XPATH, '//div[@class="sc-hfsWMF cOzgMB"]')]
        ratings = [r.split(" ")[0] for r in ratings_raw if r]

        timings = [elem.text for elem in driver.find_elements(By.XPATH, '//span[@class="sc-kasBVs dfwCXs"]')]
        phones = [elem.text for elem in driver.find_elements(By.XPATH, '//a[@class="sc-bFADNz leEVAg"]')]
        # img_urls = [elem.get_attribute('src') for elem in driver.find_elements(By.XPATH, '//div[@class="sc-iipuKH dNVxsS"]/div/img') if elem.get_attribute('src')]
        addresses = [elem.text for elem in driver.find_elements(By.XPATH, '//div[@class="sc-clNaTc ckqoPM"]')]
        descriptions = [elem.text for elem in driver.find_elements(By.XPATH, '//div[@class="sc-ZUflv bAkeQY"]')]
        img_urls = scroll_and_collect_images(driver)

        print(img_urls)
        print(ratings)

        return url, names, ratings, timings, phones, img_urls, addresses, descriptions
    except Exception as e:
        print(f"Scrape error ({url}):", e)
    finally:
        driver.quit()

def save_to_excel(db):
    cursor = db.cursor()
    cursor.execute("SELECT * FROM zip_code_pdp")
    data = cursor.fetchall()
    columns = [desc[0] for desc in cursor.description]
    df = pd.DataFrame(data, columns=columns)
    file_name = "Zomato_PDP_Data.xlsx"
    df.to_excel(file_name, index=False)
    print(f"Data saved to {file_name}")

def main():
    db, cursor = database_creation()
    f_urls = fetch_urls()
    for url in f_urls:
        data = scrape_data(url)
        if data:
            insert_data(db, cursor, *data)
    save_to_excel(db)
    db.close()

if __name__ == "__main__":
    main()
