import hashlib
import os
import pymysql
import time
import pandas as pd
from Demos.FileSecurityTest import permissions_dir_inherit
from selenium import webdriver
from selenium.webdriver.common.by import By

def generate_hashid(url):
    return hashlib.md5(url.encode()).hexdigest()

def database_creation():
    try:
        db = pymysql.connect(host="localhost", user='root', password="xbyte")
        cursor = db.cursor()
        cursor.execute("CREATE DATABASE IF NOT EXISTS zomato_4000010_250313_125102__thursday")
        db.commit()
        print("Database created")
    except Exception as e:
        print("Database creation error:", e)

    try:
        db = pymysql.connect(host="localhost", user="root", password="xbyte", database="zomato_4000010_250313_125102__thursday")
        cursor = db.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS zip_code_pdp_4000010(
                ID INT NOT NULL AUTO_INCREMENT,
                hash_id TEXT UNIQUE,
                Product_url TEXT,
                Restaurant_name TEXT,
                Ratings TEXT,
                Open_timing TEXT,
                Phone_no TEXT,
                Img_url TEXT,
                Address TEXT,
                Restaurant_Desc TEXT,
                Status VARCHAR(50) DEFAULT "Pending",
                PRIMARY KEY (ID)
            )
        """)
        db.commit()
        print("Table created")
    except Exception as e:
        print("Table creation error:", e)
    return db, cursor

def fetch_urls():
    conn, cursor = database_creation()
    try:
        cursor.execute("SELECT Product_url FROM zip_pl_code_4000010")
        urls = cursor.fetchall()
        return [url[0] for url in urls]
    except Exception as e:
        print("Error fetching URLs:", e)
    finally:
        cursor.close()
        conn.close()

def insert_data(db, cursor, url, name, rating, timing, phone, img_url, address, description):
    try:
        hash_id = generate_hashid(url)
        cursor.execute("""
            INSERT INTO Zip_code_pdp_4000010 (hash_id, Product_url, Restaurant_name, Ratings, Open_timing, Phone_no, Img_url, Address, Restaurant_Desc, Status)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, 'Done')
        """, (hash_id, url, name, rating, timing, phone, img_url, address, description))
        db.commit()
        print("Data insert succussfully")
    except Exception as e:
        print("Insertion error:", e)

def scrape_data(url):
    driver = webdriver.Edge()
    driver.maximize_window()
    try:
        driver.get(url)
        time.sleep(5)

        hash_id = generate_hashid(url)
        directory = "./01_4000010_Zomato_pdp_html_pages"
        os.makedirs(directory, exist_ok=True)
        file_name = os.path.join(directory, f"{hash_id}.html")
        with open(file_name, 'w', encoding="utf-8") as f:
            f.write(driver.page_source)
        print(f"Saved HTML: {file_name}")

        try:
            name = driver.find_element(By.XPATH, '//h1[@class="sc-7kepeu-0 sc-iSDuPN fwzNdh"]').text

        except Exception as e:
            print(f"***Name error : {e}")

        try:
            # //div[@class="sc-hfsWMF cOzgMB"]/@title
            rating = driver.find_element(By.XPATH, '//div[@class="sc-hfsWMF cOzgMB"]').get_attribute('title')
        except Exception as e:
            print(f"***Rating error : {e}")

        try:
            timing = driver.find_element(By.XPATH, '//span[@class="sc-kasBVs dfwCXs"]').text
        except Exception as e:
            print(f"***Timing error : {e}")

        try:
            phone = driver.find_element(By.XPATH, '//a[@class="sc-bFADNz leEVAg"]').text
        except Exception as e:
            print(f"***Phone error : {e}")

        try:
            img_url = driver.find_element(By.XPATH, '//div[@class="sc-iipuKH dNVxsS"]/div/img').get_attribute('src')
        except Exception as e:
            print(f"***Img_url : {e}")

        try:
            address = driver.find_element(By.XPATH, '//div[@class="sc-clNaTc ckqoPM"]').text
        except Exception as e:
            print(f"***Address : {e}")

        try:
            description = driver.find_element(By.XPATH, '//div[@class="sc-ZUflv bAkeQY"]').text
        except Exception as e:
            print(f"***Description : {e}")

        print(f"Scraped: {url}")
        return url, name, rating, timing, phone, img_url, address, description
    except Exception as e:
        print(f"Scrape error ({url}):", e)
    finally:
        driver.quit()

def save_to_excel(db):
    cursor = db.cursor()
    cursor.execute("SELECT * FROM Zip_code_pdp_4000010")
    data = cursor.fetchall()
    columns = [desc[0] for desc in cursor.description]
    df = pd.DataFrame(data, columns=columns)
    file_name = "Zomato_PDP_Data.xlsx"
    df.to_excel(file_name, index=False)
    print(f"Data saved to {file_name}")

def main():
    db, cursor = database_creation()
    urls = fetch_urls()
    for url in urls:
        data = scrape_data(url)
        if data:
            insert_data(db, cursor, *data)
    save_to_excel(db)
    db.close()

if __name__ == "__main__":
    main()


# print(name)
# print(rating)
# print(timing)
# print(phone)
# print(img_url)
# print(address)
# print(description)

# whole code is complete without an error thanks gpt.ab usme ak url hai usme multiple items hai to abhi is code only first item hi get ho rahi hai.to sari items aani  chahiye.