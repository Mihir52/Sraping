import hashlib
from string import hexdigits
from encodings.utf_7 import encode
import pymysql
from pymongo import MongoClient
from pymysql.constants.FIELD_TYPE import TIMESTAMP
from pywinauto.mouse import scroll
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from twisted.conch.insults.window import cursor
from twisted.names.client import query
from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.microsoft import EdgeChromiumDriverManager
import datetime
import time
from datetime import datetime

def generate_hashid(url):
    return hashlib.md5(url.encode()).hexdigest()


def database_creation():
    try:
        now = datetime.now()
        date_time = now.strftime("%y%m%d_%H%M%S")
        day = now.strftime("%A")
        db_name = f"Zomato_4000010_{date_time}__{day}"

        db = pymysql.connect(host="localhost", user='root', password="xbyte")
        cursor = db.cursor()

        cursor.execute(f"CREATE DATABASE IF NOT EXISTS {db_name}")
        db.commit()
    except Exception as e:
        print("database_creation****", e)

    try:
        db = pymysql.connect(host="localhost", user="root", password="xbyte", database=db_name)
        cursor = db.cursor()

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS Zip_Pl_code_4000010(
                ID INT NOT NULL AUTO_INCREMENT,
                hash_id TEXT,
                Product_url TEXT,
                Status VARCHAR(50) DEFAULT "Pending",
                PRIMARY KEY (ID)
            )
        """)

        db.commit()
    except Exception as e:
        print("Table creation****", e)

    return db, cursor

def insert_data(db,cursor,url):
    try:
        hash_id = generate_hashid(url)
        cursor.execute("INSERT INTO Zip_Pl_code_4000010(hash_id,Product_url,Status) VALUES (%s,%s,'Done')",(hash_id,url))
        db.commit()
    except Exception as e:
        print(f"***Insertion error : {e}")

def Zomato_pl_scrape():
    driver = webdriver.Edge()
    driver.maximize_window()

    url = "https://www.zomato.com/mumbai/mazgaon-restaurants?category=1&delivery_subzone=3495&place_name=4000010%2C++Anjeer+Wadi%2C++Thakkar+Estate"
    driver.get(url)
    time.sleep(5)

    l_height = driver.execute_script("return document.body.scrollHeight")

    while True:
        driver.execute_script("window.scrollBy(0, 10000);")
        time.sleep(2)
        new_height = driver.execute_script("return document.body.scrollHeight")
        print("n : ", new_height, "l : ", l_height)

        if new_height == l_height:
            break
        l_height = new_height

    restaurant_elements = driver.find_elements(By.XPATH, '//a[@class="sc-hPeUyl cKQNlu"]')
    restaurant_links = [link.get_attribute("href") for link in restaurant_elements if link.get_attribute("href")]
    print(restaurant_links)
    print("Total links",len(restaurant_links))

    html_content = driver.page_source
    with open("4000010_Pl.html",'w',encoding="utf-8") as f:
        f.write(html_content)

    print("Save html page successfully")

    driver.quit()

    return restaurant_links

def main():
    db,cursor = database_creation()
    restaurant_links = Zomato_pl_scrape()
    for link in restaurant_links:
        insert_data(db,cursor,link)

    print("Data insert successfully")
    db.close()

main()

# Total links 1175


