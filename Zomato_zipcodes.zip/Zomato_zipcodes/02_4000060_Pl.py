import hashlib
from string import hexdigits
from encodings.utf_7 import encode
import pymysql
from pymongo import MongoClient
from pymysql.constants.FIELD_TYPE import TIMESTAMP
from pywinauto.mouse import scroll
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from twisted.conch.insults.window import cursor
from twisted.names.client import query
from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.microsoft import EdgeChromiumDriverManager
import datetime
import time
from datetime import datetime
import pandas as pd

def generate_hashid(url):
    return hashlib.md5(url.encode()).hexdigest()

def database_creation():
    try:
        now = datetime.now()
        date_time = now.strftime("%y%m%d_%H%M%S")
        day = now.strftime("%A")
        db_name = f"Zomato_4000060_{date_time}__{day}"

        db = pymysql.connect(host="localhost", user='root', password="xbyte")
        cursor = db.cursor()

        cursor.execute(f"CREATE DATABASE IF NOT EXISTS {db_name}")
        db.commit()
    except Exception as e:
        print("database_creation****", e)

    try:
        db = pymysql.connect(host="localhost", user="root", password="xbyte", database=db_name)
        cursor = db.cursor()

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS Zip_Pl_code_4000060(
                ID INT NOT NULL AUTO_INCREMENT,
                hash_id TEXT,
                Product_url TEXT,
                Status VARCHAR(50) DEFAULT "Pending",
                PRIMARY KEY (ID)
            )
        """)

        db.commit()
    except Exception as e:
        print("Table creation****", e)

    return db, cursor

def insert_data(db,cursor,url):
    try:
        hash_id = generate_hashid(url)
        cursor.execute("INSERT INTO Zip_Pl_code_4000060(hash_id,Product_url) VALUES (%s,%s)",(hash_id,url))
        db.commit()
    except Exception as e:
        print(f"***Insertion error : {e}")

def Zomato_pl_scrape():
    driver = webdriver.Edge()
    driver.minimize_window()

    url = "https://www.zomato.com/mumbai/delivery-in-dahisar-west?delivery_subzone=11669&place_name=400006%2C++Ranchhod+das+Road%2C++Tawde+Wadi"
    driver.get(url)
    time.sleep(5)

    l_height = driver.execute_script("return document.body.scrollHeight")

    while True:
        driver.execute_script("window.scrollBy(0, 20000);")
        time.sleep(2)
        new_height = driver.execute_script("return document.body.scrollHeight")
        print("n : ", new_height, "l : ", l_height)

        if new_height == l_height:
            break
        l_height = new_height

    restaurant_elements = driver.find_elements(By.XPATH, '//a[@class="sc-hPeUyl cKQNlu"]')
    restaurant_links = [link.get_attribute("href") for link in restaurant_elements if link.get_attribute("href")]
    print(restaurant_links)
    print("Total links",len(restaurant_links))

    html_content = driver.page_source
    with open("02_4000060_Pl.html",'w',encoding="utf-8") as f:
        f.write(html_content)

    print("Save html page successfully")

    driver.quit()

    return restaurant_links

def save_to_excel(db):
    cursor = db.cursor()
    cursor.execute("SELECT * FROM Zip_Pl_code_4000060")
    data = cursor.fetchall()
    columns = [desc[0] for desc in cursor.description]
    df = pd.DataFrame(data, columns=columns)
    file_name = "02_Zomato_Pl_Data.xlsx"
    df.to_excel(file_name, index=False)
    print(f"Data saved to {file_name}")

def main():
    db,cursor = database_creation()
    restaurant_links = Zomato_pl_scrape()
    for link in restaurant_links:
        insert_data(db,cursor,link)
    save_to_excel(db)

    print("Data insert successfully")
    db.close()

main()


#  Total = 909