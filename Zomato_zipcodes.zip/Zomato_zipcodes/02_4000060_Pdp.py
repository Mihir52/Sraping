import hashlib
import os
import time
import pymysql
import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.by import By

def generate_hashid(url):
    return hashlib.md5(url.encode()).hexdigest()

def database_creation():
    try:
        db = pymysql.connect(host="localhost", user='root', password="xbyte")
        cursor = db.cursor()
        cursor.execute("CREATE DATABASE IF NOT EXISTS zomato_4000060_250313_180723__thursday")
        db.commit()
        print("Database created")
    except Exception as e:
        print("Database creation error:", e)

    try:
        db = pymysql.connect(host="localhost", user="root", password="xbyte", database="zomato_4000060_250313_180723__thursday")
        cursor = db.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS zip_code_pdp_4000060(
                ID INT NOT NULL AUTO_INCREMENT,
                hash_id TEXT,
                Product_url TEXT,
                Restaurant_name TEXT,
                Ratings TEXT,
                Open_timing TEXT,
                Phone_no TEXT,
                Img_url TEXT,
                Address TEXT,
                Restaurant_Desc TEXT,
                Status VARCHAR(50) DEFAULT "Pending",
                PRIMARY KEY (ID)
            )
        """)
        db.commit()
        print("Table created")
    except Exception as e:
        print("Table creation error:", e)
    return db, cursor

# def fetch_urls():
#     conn, cursor = database_creation()
#     try:
#         cursor.execute("SELECT Product_url FROM Zip_Pl_code_4000060")
#         urls = cursor.fetchall()
#         return [url[0] for url in urls]
#     except Exception as e:
#         print("Error fetching URLs:", e)
#     finally:
#         cursor.close()
#         conn.close()

def fetch_urls():
    conn, cursor = database_creation()
    try:
        cursor.execute("SELECT Product_url FROM zip_pl_code_4000060 WHERE Status = 'Pending'")
        urls = cursor.fetchall()
        return [url[0] for url in urls]
    except Exception as e:
        print("Error fetching URLs:", e)
    finally:
        cursor.close()
        conn.close()

# def insert_data(db, cursor, url, names, ratings, timings, phones, img_urls, addresses, descriptions):
#     try:
#         hash_id = generate_hashid(url)
#         cursor.execute("""
#             INSERT INTO zip_code_pdp_4000010 (hash_id, Product_url, Restaurant_name, Ratings, Open_timing, Phone_no, Img_url, Address, Restaurant_Desc, Status)
#             VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, 'Done')
#         """, (hash_id, url, ", ".join(names), ", ".join(ratings), ", ".join(timings), ", ".join(phones), ", ".join(img_urls), ", ".join(addresses), ", ".join(descriptions)))
#         db.commit()
#         print("Data inserted successfully")
#     except Exception as e:
#         print("Insertion error:", e)

def insert_data(db, cursor, url, names, ratings, timings, phones, img_urls, addresses, descriptions):
    try:
        hash_id = generate_hashid(url)
        cursor.execute("""
            INSERT INTO zip_code_pdp_4000060 (hash_id, Product_url, Restaurant_name, Ratings, Open_timing, Phone_no, Img_url, Address, Restaurant_Desc, Status)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, 'Done')
        """, (
        hash_id, url, ", ".join(names), ", ".join(ratings), ", ".join(timings), ", ".join(phones), ", ".join(img_urls),
        ", ".join(addresses), ", ".join(descriptions)))

        # **Update Status in PL table**
        cursor.execute("UPDATE zip_pl_code_4000060 SET Status = 'Done' WHERE Product_url = %s", (url,))

        db.commit()
        print("Data inserted successfully and Status Updated")
    except Exception as e:
        print("Insertion error:", e)

def scroll_and_collect_images(driver):
    last_height = driver.execute_script("return document.body.scrollHeight")

    while True:
        # Scroll down
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(2)  # Wait for new images to load

        new_height = driver.execute_script("return document.body.scrollHeight")
        if new_height == last_height:
            break  # Stop if no more scrolling
        last_height = new_height

    # Collect all images
    img_urls = [elem.get_attribute('src') for elem in driver.find_elements(By.TAG_NAME, 'img') if elem.get_attribute('src')]
    return img_urls

def scrape_data(url):
    driver = webdriver.Edge()
    driver.maximize_window()
    try:
        driver.get(url)
        time.sleep(5)

        hash_id = generate_hashid(url)
        directory = "./Zomato_PDP_HTML"
        os.makedirs(directory, exist_ok=True)
        file_name = os.path.join(directory, f"{hash_id}.html")
        with open(file_name, 'w', encoding="utf-8") as f:
            f.write(driver.page_source)
        print(f"Saved HTML: {file_name}")

        names = [elem.text for elem in driver.find_elements(By.XPATH, '//h1[@class="sc-7kepeu-0 sc-iSDuPN fwzNdh"]')]
        # for ele in driver.find_elements(By.XPATH,'//h1[@class="sc-7kepeu-0 sc-iSDuPN fwzNdh"]'):
        #     names = ele.text
        #     print(names)
        ratings_raw = [elem.get_attribute('title') for elem in driver.find_elements(By.XPATH, '//div[@class="sc-hfsWMF cOzgMB"]')]
        ratings = [r.split(" ")[0] for r in ratings_raw if r]

        timings = [elem.text for elem in driver.find_elements(By.XPATH, '//span[@class="sc-kasBVs dfwCXs"]')]
        phones = [elem.text for elem in driver.find_elements(By.XPATH, '//a[@class="sc-bFADNz leEVAg"]')]
        # img_urls = [elem.get_attribute('src') for elem in driver.find_elements(By.XPATH, '//div[@class="sc-iipuKH dNVxsS"]/div/img') if elem.get_attribute('src')]
        addresses = [elem.text for elem in driver.find_elements(By.XPATH, '//div[@class="sc-clNaTc ckqoPM"]')]
        descriptions = [elem.text for elem in driver.find_elements(By.XPATH, '//div[@class="sc-ZUflv bAkeQY"]')]
        img_urls = scroll_and_collect_images(driver)

        print(img_urls)
        print(ratings)

        return url, names, ratings, timings, phones, img_urls, addresses, descriptions
    except Exception as e:
        print(f"Scrape error ({url}):", e)
    finally:
        driver.quit()

def save_to_excel(db):
    cursor = db.cursor()
    cursor.execute("SELECT * FROM zip_code_pdp_4000060")
    data = cursor.fetchall()
    columns = [desc[0] for desc in cursor.description]
    df = pd.DataFrame(data, columns=columns)
    file_name = "02_Zomato_PDP_Data.xlsx"
    df.to_excel(file_name, index=False)
    print(f"Data saved to {file_name}")

def main():
    db, cursor = database_creation()
    f_urls = fetch_urls()
    for url in f_urls:
        data = scrape_data(url)
        if data:
            insert_data(db, cursor, *data)
    save_to_excel(db)
    db.close()

if __name__ == "__main__":
    main()
